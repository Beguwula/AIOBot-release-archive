# AIOBot
AIOBot is a bot that does (almost) everything except raid (when it's done, still won't raid though).
## Current list of modules
### Welcomer
Welcomer sends a dm the any user when they join, and optionally a welcome message in the specified channel.
